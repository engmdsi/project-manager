<?php
// db.php
$host = 'localhost';
$dbname = 'karapum1_reminderdb';
$user = 'karapum1_reminderuser';   // معمولاً همون یوزر 
$pass = '@Mahmood68';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("اتصال نشد: " . htmlspecialchars($e->getMessage()));
}

// تبدیل تقریبی میلادی → شمسی (برای نمایش)
function toJalali($gregorian_date) {   // ورودی: 2025-04-15
    if (!$gregorian_date || $gregorian_date == '0000-00-00') return '-';
    list($gy, $gm, $gd) = explode('-', $gregorian_date);
    $gy = (int)$gy; $gm = (int)$gm; $gd = (int)$gd;

    $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

    $jy = $gy - 621;
    $leap = ($gy % 33 != 1) ? 0 : 1; // تقریبی

    $g_day_no = 365 * ($gy - 1) + (int)(($gy - 1) / 4) - (int)(($gy - 1) / 100) + (int)(($gy - 1) / 400);
    for ($i = 0; $i < $gm - 1; ++$i) $g_day_no += $g_days_in_month[$i];
    if ($gm > 2 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0))) $g_day_no++;
    $g_day_no += $gd - 1;

    $j_day_no = $g_day_no - 79;
    $j_np = (int)($j_day_no / 12053);
    $j_day_no %= 12053;

    $jy += 979 + 33 * $j_np + 4 * (int)($j_day_no / 1461);
    $j_day_no %= 1461;

    if ($j_day_no >= 366) {
        $jy += (int)(($j_day_no - 1) / 365);
        $j_day_no = ($j_day_no - 1) % 365;
    }

    $jm = 0;
    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) {
        $j_day_no -= $j_days_in_month[$i];
        $jm++;
    }
    $jd = $j_day_no + 1;

    return sprintf("%04d-%02d-%02d", $jy, $jm + 1, $jd);
}

// شمسی → میلادی (برای ذخیره – تقریبی – فرمت ورودی 1404-01-25)
function toGregorian($jalali_date) {
    if (!$jalali_date || !preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $jalali_date, $m)) {
        return date('Y-m-d');
    }
    $jy = (int)$m[1]; $jm = (int)$m[2]; $jd = (int)$m[3];

    $j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];

    $j_day_no = ($jy - 979) * 365 + (int)(($jy - 979) / 33) * 8 + (int)((($jy - 979) % 33 + 3) / 4);
    for ($i = 0; $i < $jm - 1; ++$i) $j_day_no += $j_days_in_month[$i];
    $j_day_no += $jd - 1;

    $g_day_no = $j_day_no + 79;
    $gy = 1600 + 400 * (int)($g_day_no / 146097);
    $g_day_no = $g_day_no % 146097;

    $leap = true;
    if ($g_day_no >= 36525) {
        $g_day_no--;
        $gy += 100 * (int)($g_day_no / 36524);
        $g_day_no = $g_day_no % 36524;
        if ($g_day_no >= 365) $g_day_no++;
        else $leap = false;
    }

    $gy += 4 * (int)($g_day_no / 1461);
    $g_day_no %= 1461;

    if ($g_day_no >= 366) {
        $leap = false;
        $g_day_no--;
        $gy += (int)($g_day_no / 365);
        $g_day_no = $g_day_no % 365;
    }

    $gm = 0;
    $g_days_in_month = $leap ? [0,31,29,31,30,31,30,31,31,30,31,30,31] : [0,31,28,31,30,31,30,31,31,30,31,30,31];
    while ($g_day_no >= $g_days_in_month[$gm + 1]) {
        $g_day_no -= $g_days_in_month[++$gm];
    }
    $gd = $g_day_no + 1;

    return sprintf("%04d-%02d-%02d", $gy, $gm, $gd);
}